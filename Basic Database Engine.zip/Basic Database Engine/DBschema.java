//package dubstep;
/**
 * Created by shruti on 11/4/17.
 */
class DBschema
{
    int index;
    String datatype;

    public DBschema(int i,String d)
    {
        this.index = i;
        this.datatype =d;
    }
}